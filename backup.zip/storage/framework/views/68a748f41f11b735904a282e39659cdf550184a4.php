   <!--begin::Head-->
   <head>
    <base href="">
    <meta charset="utf-8" />
    <title>BhavnagarMandali | <?php echo e((@$pagetitle) ? $pagetitle : 'Static'); ?> </title>
    <meta name="description" content="Metronic admin dashboard live demo. Check out all the features of the admin panel. A large number of settings, additional services and widgets." />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
    
    <!--begin::Fonts-->
    <link rel="stylesheet" href="<?php echo e(('https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700')); ?>" />
    <!--end::Fonts-->

    <!--begin::Global Theme Styles(used by all pages)-->
    <link href="<?php echo e(asset('common/css/plugin/tailwind.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('assets/plugins/global/plugins.bundle.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('assets/css/style.bundle.css')); ?>" rel="stylesheet" type="text/css" />
    <!--end::Global Theme Styles-->

    <!--begin::Layout Themes(used by all pages)-->
    <link href="<?php echo e(asset('assets/css/themes/layout/header/base/light.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('assets/css/themes/layout/header/menu/light.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('assets/css/themes/layout/brand/dark.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('assets/css/themes/layout/aside/dark.css')); ?>" rel="stylesheet" type="text/css" />

    <link href="<?php echo e(asset('common/css/plugin/kendo.common.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('common/css/plugin/kendo.default-v2.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('common/css/plugin/newdesigntailwind.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('common/css/common.css')); ?>" rel="stylesheet" type="text/css" />
    <script>
        var site_url = "<?php echo e(url('/')); ?>/";
    </script>
    <!--end::Layout Themes-->
    <link rel="shortcut icon" href="<?php echo e(asset('assets/media/logos/favicon.ico')); ?>" />

    <?php if(!empty($css)): ?>
            <?php $__currentLoopData = $css; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(!empty($value)): ?>
                    <link rel="stylesheet" href="<?php echo e(asset('common/css/custom/'.$value)); ?>">
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<?php endif; ?>


		<?php if(!empty($plugincss)): ?>
			<?php $__currentLoopData = $plugincss; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php if(!empty($value)): ?>
					<link rel="stylesheet" href="<?php echo e(asset('common/css/plugin/'.$value)); ?>">
				<?php endif; ?>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<?php endif; ?>
 </head>
 <!--end::Head-->
<?php /**PATH D:\xampp\htdocs\bhavnagarmandali\resources\views/includes/header.blade.php ENDPATH**/ ?>