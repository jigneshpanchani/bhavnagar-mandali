

<?php $__env->startSection('content'); ?>

<div class="subheader py-2 py-lg-4 subheader-solid" id="kt_subheader">
    <div class="container-fluid d-flex align-items-center justify-content-between flex-wrap flex-sm-nowrap">
        <div class="d-flex align-items-center flex-wrap mr-2">
        <h5 class="text-dark font-weight-bold mt-2 mb-2 mr-5"><?php echo e(($pagetitle) ? $pagetitle : 'Static'); ?></h5>
        </div>
        <button class="addsubsceme btn btn-primary font-weight-bolder btn-sm justify-end">Add Sub-Sceme</button>
    </div>
</div>

<div class="bg-white p-1 rounded">
    <div id='subscemeList'></div>
</div>

<div id="addSubScemeModal" style="display:none;">
    <form id="addSubScemeForm">
    </form>
</div>

<div id="editSubScemeModal" style="display:none">
    <form id="editSubScemeForm">
    </form>
</div>

<div id="deleteSubScemenModal" style="display: none"></div>

<script type="text/javascript">
    var login_id = "<?php echo e($login_id); ?>";
</script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\bhavnagarmandali\resources\views/pages/sub-sceme.blade.php ENDPATH**/ ?>