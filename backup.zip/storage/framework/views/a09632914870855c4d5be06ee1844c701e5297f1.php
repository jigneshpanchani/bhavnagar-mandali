<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('section'); ?>



<?php $__env->stopSection(); ?>
<?php /**PATH D:\xampp\htdocs\bhavnagarmandali\resources\views/welcome.blade.php ENDPATH**/ ?>