

<?php $__env->startSection('content'); ?>

<div class="subheader py-2 py-lg-4 subheader-solid" id="kt_subheader">
    <div class="container-fluid d-flex align-items-center justify-content-between flex-wrap flex-sm-nowrap">
        <div class="d-flex align-items-center flex-wrap mr-2">
            <h5 class="text-dark font-weight-bold mt-2 mb-2 mr-5"><?php echo e((@$pagetitle) ? $pagetitle : 'Static'); ?></h5>
        </div>
                <input type="hidden" value="<?php echo e($customer); ?>" name="accountno" id="accountNo">
                <input type ="hidden" value="<?php echo e($rateofint); ?>" name="rateofint" id="rateogInt">
                
                <button class="addyojna btn btn-primary font-weight-bolder btn-sm justify-end">Add Yojna</button>
    </div>
</div>

<div class="bg-white p-1 rounded">
    <div id='yojnaList'></div>
</div>



<div id="addYojnaModal" style="display:none;">
    <form id="addYojnaForm">
    </form>
</div>

<div id="customerTransactionBachatModal" style="display:none;">
    <form id="customertransactionform">
    
    </form>
</div>

<div id="customerTransactionLoanModal" style="display:none;">
    <form id="customertransactionloanform">
    </form>
</div>

<div id="customerFdModal" style="display:none;">
    <form id="customerFdform">
    </form>
</div>

<div id="vyavaharModal" style="display:none;">
    <form id="vyavaharForm"></form>
</div> 

<div id="transactiondetailModal" style="display:none;">
    <div id="transactiondetailList"></div>
</div> 

<script>
    var member_id = "<?php echo $customerId ?>";
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\bhavnagarmandali1\resources\views/pages/yojna.blade.php ENDPATH**/ ?>