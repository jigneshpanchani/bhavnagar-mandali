<!DOCTYPE html>

<html lang="en">

    <?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   <!--begin::Body-->
   <body id="kt_body" class="header-fixed header-mobile-fixed subheader-enabled subheader-fixed aside-enabled aside-fixed aside-minimize-hoverable">
      <!--begin::Main-->

      <div class="d-flex flex-column flex-root">
         <!--begin::Page-->
         <div class="d-flex flex-row flex-column-fluid page">

            <?php echo $__env->make('includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <!--begin::Wrapper-->
            <div class="d-flex flex-column flex-row-fluid wrapper" id="kt_wrapper">
         
                <?php echo $__env->make('includes.bodyheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <!--begin::Content-->
                <div class="content d-flex flex-column flex-column-fluid" id="kt_content">

                <!--begin::Subheader-->
            
                  <!--end::Subheader-->

                  <div class="d-flex flex-column-fluid">
                    <div class="w-full p-2">
                        <?php echo $__env->yieldContent('content'); ?>

                    </div>
                  </div>
                </div>
                <!--end::Content-->
            </div>
            <!--end::Wrapper-->
         </div>
         <!--end::Page-->
      </div>
      <!--end::Main-->


      <?php echo $__env->make('includes.userpanel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

      <?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!--end::Page Scripts-->
   </body>
   <!--end::Body-->
</html>
<?php /**PATH D:\xampp\htdocs\bhavnagarmandali\resources\views/layouts/layout.blade.php ENDPATH**/ ?>