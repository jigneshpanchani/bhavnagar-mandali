

<?php $__env->startSection('content'); ?>

<div class="subheader py-2 py-lg-4 subheader-solid" id="kt_subheader">
    <div class="container-fluid d-flex align-items-center justify-content-between flex-wrap flex-sm-nowrap">
        <div class="d-flex align-items-center flex-wrap mr-2">
            <h5 class="text-dark font-weight-bold mt-2 mb-2 mr-5"><?php echo e((@$pagetitle) ? $pagetitle : 'Static'); ?></h5>
        </div>
    </div>
</div>

<div id='reportsList'></div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\bhavnagarmandali1\resources\views/pages/reports.blade.php ENDPATH**/ ?>